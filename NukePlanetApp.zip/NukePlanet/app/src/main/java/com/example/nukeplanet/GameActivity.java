//Brooks Franklin, CIS165DA Section #12151, MEID: bro2152333
package com.example.nukeplanet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class GameActivity extends AppCompatActivity {

    public TextView txtScore;

    private ImageView[] planets = new ImageView[6];
    private int wrongPlanetIndex; // Index of the wrong planet
    public static int points = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Initialize ImageView references for all planets
        planets[0] = findViewById(R.id.planet1);
        planets[1] = findViewById(R.id.planet2);
        planets[2] = findViewById(R.id.planet3);
        planets[3] = findViewById(R.id.planet4);
        planets[4] = findViewById(R.id.planet5);
        planets[5] = findViewById(R.id.planet6);

        // Set click listeners for all planets using a loop
        for (ImageView planet : planets) {
            planet.setOnClickListener(this::onPlanetClicked);
        }

        // Randomly select a wrong planet
        randomizeWrongPlanet();

        txtScore = findViewById(R.id.scoreView);
    }

    // Method to randomize the wrong planet
    private void randomizeWrongPlanet() {
        Random random = new Random();
        wrongPlanetIndex = random.nextInt(planets.length); // Selects a random index from 0 to 5
    }

    // Method to handle planet selection
    public void onPlanetClicked(View view) {
        ImageView selectedPlanet = (ImageView) view;

        if (selectedPlanet != planets[wrongPlanetIndex]) {
            // The user selected the wrong planet
            Toast.makeText(this, "Game Over! You selected the wrong planet.", Toast.LENGTH_LONG).show();
            Intent editPage = ((Intent) MainActivity.intScore.clone()).putExtra("allowEdit",true).putExtra("score", points);
            startActivity(editPage);
            finish();
        } else {
            // The user selected a correct planet
            Toast.makeText(this, "Correct! You got " + 100 + " points.", Toast.LENGTH_SHORT).show();
            points += 100;
            // Optionally, you can randomize the wrong planet again for the next selection
            randomizeWrongPlanet();
        }
        txtScore.setText("Score: " + points);  // Update the TextView with the new score
    }

}