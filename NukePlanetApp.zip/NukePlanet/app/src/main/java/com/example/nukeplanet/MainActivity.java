//Brooks Franklin, CIS165DA Section #12151, MEID: bro2152333
package com.example.nukeplanet;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button startGameButton, viewScoresButton, openLinkButton;

    public static Intent intScore;
    public static Intent main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        main = new Intent(MainActivity.this, MainActivity.class);
        if(intScore == null) intScore = new Intent(MainActivity.this, ScoreActivity.class);
        Intent scoreActivity = ((Intent) intScore.clone()).putExtra("allowEdit",false);

        startGameButton = findViewById(R.id.startGameButton);
        viewScoresButton = findViewById(R.id.viewScoresButton);

        startGameButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, GameActivity.class)));
        viewScoresButton.setOnClickListener(v -> startActivity(scoreActivity));

    }
    // Method to open the web link
    public void openLink(View view) {
        // Define the URL
        String url = "https://github.com/BrooksF16?tab=projects"; // Replace "https://example.com" with your desired URL

        // Create an Intent to open the URL in a web browser
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

        // Start the Intent
        startActivity(intent);
    }
}
