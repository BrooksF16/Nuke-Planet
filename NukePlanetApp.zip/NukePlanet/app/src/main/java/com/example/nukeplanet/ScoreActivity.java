//Brooks Franklin, CIS165DA Section #12151, MEID: bro2152333
package com.example.nukeplanet;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.nukeplanet.db.DatabaseHelper;
import com.example.nukeplanet.db.Score;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ScoreActivity extends AppCompatActivity {

    private TextView txtScore, txtDate;
    private EditText edtName;
    private static SQLiteDatabase database;
    private static DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(dbHelper == null) {
            dbHelper = new DatabaseHelper(this);
            open();
        }
        setContentView(R.layout.activity_score);
        Bundle bundle = getIntent().getExtras();

        // Initialize TextViews and EditText
        txtScore = findViewById(R.id.txtScore);
        txtDate = findViewById(R.id.txtDate);
        edtName = findViewById(R.id.edtName);

        if(bundle.getBoolean("allowEdit")) {
            // Display current date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdf.format(new Date());
            txtDate.setText(currentDate);
            txtScore.setText(String.valueOf(bundle.getInt("score")));
            Button btnSubmitName = findViewById(R.id.btnSubmitName);
            btnSubmitName.setText("Submit Score");
            btnSubmitName.setOnClickListener(this::submitScore);
        } else {
            if( getAllScores().isEmpty()) {
                txtScore.setText("Play the game and then come back");
                return;
            }
            Score user = (Score) getAllScores().toArray()[getAllScores().toArray().length - 1];
            txtScore.setText(String.valueOf(user.getScore())); // Display user score from DB
            txtDate.setText(user.getDate()); // Display user date from DB
            edtName.setText(user.getName()); // Display user name from DB

            Button btnSubmitName = findViewById(R.id.btnSubmitName);
            btnSubmitName.setText("Delete");
            btnSubmitName.setOnClickListener(view -> deleteSave(view, edtName.getText().toString()));
        }
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void save(){
        database.setTransactionSuccessful();
        database.endTransaction();
    }


    public void addScore(String name, int score, String date) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NAME, name);
        values.put(DatabaseHelper.COLUMN_SCORE, score);
        values.put(DatabaseHelper.COLUMN_DATE, date);
        database.insert(DatabaseHelper.TABLE_NAME, null, values);
    }

    public void deleteSave(View view, String name) {
        deleteScore(name);
        startActivity(MainActivity.main);
        finish();
    }

    // Method to handle submitting the score with the user's name
    public void submitScore(View view) {
        String name = edtName.getText().toString().trim();
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter your name.", Toast.LENGTH_SHORT).show();
            return;
        }
        int score = Integer.parseInt(txtScore.getText().toString());
        String date = txtDate.getText().toString();
        addScore(name, score, date);
        Toast.makeText(this, "Score saved successfully.", Toast.LENGTH_SHORT).show();
        finish();
    }

    public void deleteScore(String name) {
        database.delete(DatabaseHelper.TABLE_NAME, DatabaseHelper.COLUMN_NAME + " = ?", new String[]{name});
    }

    public List<Score> getAllScores() {
        List<Score> scores = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, null, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Score score = cursorToScore(cursor);
            scores.add(score);
            cursor.moveToNext();
        }
        cursor.close();
        return scores;
    }

    private Score cursorToScore(Cursor cursor) {
        int nameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
        int scoreIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_SCORE);
        int dateIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE);

        String name = cursor.getString(nameIndex);
        int score = cursor.getInt(scoreIndex);
        String date = cursor.getString(dateIndex);

        return new Score(name, score, date);
    }
}
