//Brooks Franklin, CIS165DA Section #12151, MEID: bro2152333
package com.example.nukeplanet.db;

public class Score {
    private String name;
    private int score;
    private String date;

    public Score(String name, int score, String date) {
        this.name = name;
        this.score = score;
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public String getDate() {
        return date;
    }
}
